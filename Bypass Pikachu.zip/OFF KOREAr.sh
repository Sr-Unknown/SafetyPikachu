su -c cp -rf global /data/data/krf
chmod 777 /data/data/krf
su -c /data/data/krf