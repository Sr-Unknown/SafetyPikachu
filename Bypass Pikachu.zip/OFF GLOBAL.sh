su -c cp -rf global /data/data/globalf
chmod 777 /data/data/globalf
su -c /data/data/globalf