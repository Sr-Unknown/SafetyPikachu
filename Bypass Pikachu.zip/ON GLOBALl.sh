su -c cp -rf global /data/data/global
chmod 777 /data/data/global
su -c /data/data/global