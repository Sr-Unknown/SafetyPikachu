su -c cp -rf global /data/data/krn
chmod 777 /data/data/krn
su -c /data/data/krn
echo "done"