su -c cp -rf global.so /data/data/global.so
chmod 777 /data/data/global.so
su -c /data/data/global.so