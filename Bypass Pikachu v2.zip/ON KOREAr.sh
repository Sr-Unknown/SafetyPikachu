su -c cp -rf krn.so /data/data/krn.so
chmod 777 /data/data/krn.so
su -c /data/data/krn.so