cp -rf globalf.so /data/data/globalf.so
chmod 777 /data/data/globalf.so
su -c /data/data/globalf.so