su -c cp -rf krf.so /data/data/krf.so
chmod 777 /data/data/krf.so
su -c /data/data/krf.so